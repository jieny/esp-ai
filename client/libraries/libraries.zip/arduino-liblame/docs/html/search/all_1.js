var searchData=
[
  ['begin_0',['begin',['../classliblame_1_1_m_p3_encoder_l_a_m_e.html#a0be6b928f81d76de826faec024a9003a',1,'liblame::MP3EncoderLAME::begin()'],['../classliblame_1_1_m_p3_encoder_l_a_m_e.html#a4fb46c73fd0be4e376c1f72d875b3297',1,'liblame::MP3EncoderLAME::begin(AudioInfo in)'],['../classliblame_1_1_m_p3_encoder_l_a_m_e.html#a47b52eaec66ff4513a483d4ce6ceeb6a',1,'liblame::MP3EncoderLAME::begin(int input_channels, int input_sample_rate, int input_bits_per_sample)']]]
];
